#!/usr/bin/env bash

pip uninstall guided_filter_tf
rm -rf guided_filter_tf.egg-info/
