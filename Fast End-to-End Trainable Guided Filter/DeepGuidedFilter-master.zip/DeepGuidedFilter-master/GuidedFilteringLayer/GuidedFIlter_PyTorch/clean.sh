#!/usr/bin/env bash

pip uninstall guided_filter_pytorch
rm -rf guided_filter_pytorch.egg-info/
